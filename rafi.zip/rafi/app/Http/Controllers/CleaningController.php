<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CleaningController extends Controller
{
    //
    public function cleaner()
    {
        return view('tables');
    }
}
