<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome');
    echo "one";
});

Route::get('/satu', function () {
    // return view('welcome');
    echo "two";
});

Route::get('/dua', function () {
    // return view('welcome');
    echo "three";
});

Route::get('/tiga', function () {
    // return view('welcome');
    echo "four";
});

Route::get('/empat', function () {
    // return view('welcome');
    echo "five";
});

Route::get('/lima', function () {
    // return view('welcome');
    echo "six";
});

Route::get('/enam', function () {
    // return view('welcome');
    echo "seven";

});Route::get('/tujuh', function () {
    // return view('welcome');
    echo "eight";
});

Route::get('/delapan', function () {
    // return view('welcome');
    echo "nine";
});

Route::get('/sembilan', function () {
    // return view('welcome');
    echo "ten";
});

Route::get('/sepuluh', function () {
    // return view('welcome');
    echo "eleven";
});

// 2, manggil view

// manggil controller
route::get('/usang' ,'UsangController@index');
// file controllernya namanya usangController
    // nama url usang
    // index nama functionnya

route::get('/jeruk' ,'UsangController@godog');

route::get('/terong' ,'kentang@sandal');

route::get('/nemplate', function () {
    return view('template');
    // lokasi view
});

route::get('/' ,'Kontak@index');

route::get('/CleaningService' ,'CleaningController@cleaner');

